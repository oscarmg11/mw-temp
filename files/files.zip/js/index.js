
var tiempo = []
var datosTemperature = []
var datosHumedad = []
var datosPresion = []

$(document).ready(() => {
    startSplashScreen()

    setInterval(() => {
        $.ajax({
            url: 'index.php?last=true',
            cache: false,
            success: function(data) {
                console.log(data)
                const dataParsed = JSON.parse(data)

                const newTiempo = JSON.parse(dataParsed.tiempo)
                const newDatosTemperature = JSON.parse(dataParsed.datosTemperature)
                const newDatosHumedad = JSON.parse(dataParsed.datosHumedad)
                const newDatosPresion = JSON.parse(dataParsed.datosPresion)

                tiempo.unshift(newTiempo[0])
                datosTemperature.unshift(newDatosTemperature[0])
                datosHumedad.unshift(newDatosHumedad[0])
                datosPresion.unshift(newDatosPresion[0])
                console.log(datosPresion.length)
                console.log(datosPresion[datosPresion.length - 1])

                clearCanvas('gTemp')
                clearCanvas('gPre')
                clearCanvas('gHum')

                setInfoIndicator( newDatosTemperature[0], 'gTemp', 0, 40, '°C')
                setInfoIndicator( newDatosPresion[0], 'gPre', 0, 1000, 'hPa')
                setInfoIndicator( newDatosHumedad[0], 'gHum', 0, 100, '%')

                createChart('graficaLinealTemp', tiempo, datosTemperature, 'Grados °C')
                createChart('graficaLinealPres', tiempo, datosPresion, 'hPa')
                createChart('graficaLinealHum', tiempo, datosHumedad, '%')
            }
        });
    }, 10000);

    $.ajax({
        url: 'index.php?last=false',
        cache: false,
        success: function(data) {
            removeSplashScreen()

            const dataParsed = JSON.parse(data)

            tiempo = JSON.parse(dataParsed.tiempo)
            datosTemperature = JSON.parse(dataParsed.datosTemperature)
            datosHumedad = JSON.parse(dataParsed.datosHumedad)
            datosPresion = JSON.parse(dataParsed.datosPresion)

            setInfoIndicator( datosTemperature[0], 'gTemp', 0, 40, '°C')
            setInfoIndicator( datosPresion[0], 'gPre', 0, 1000, 'hPa')
            setInfoIndicator( datosHumedad[0], 'gHum', 0, 100, '%')

            createChart('graficaLinealTemp', tiempo, datosTemperature, 'Grados °C')
            createChart('graficaLinealPres', tiempo, datosPresion, 'hPa')
            createChart('graficaLinealHum', tiempo, datosHumedad, '%')
        }
    });
})